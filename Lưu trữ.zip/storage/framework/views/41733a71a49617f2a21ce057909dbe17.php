<!doctype html>
<html lang="en">
  <!--begin::Head-->
  <?php echo $__env->make('user.layouts.components.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!--end::Head-->
  <!--begin::Body-->
  <body class="layout-fixed fixed-header fixed-sidebar fixed-footer sidebar-expand-lg bg-body-tertiary" style="padding-bottom: 0px;">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
      <!--begin::Header-->
      <?php echo $__env->make('user.layouts.components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!--end::Header-->
      <!--begin::Sidebar-->
      <?php echo $__env->make('user.layouts.components.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!--end::Sidebar-->
      <!--begin::App Main-->
      <main class="app-main">
        <?php echo $__env->yieldContent('content'); ?>
      </main>
      <!--end::App Main-->
      <!--begin::Footer-->
      <?php echo $__env->make('user.layouts.components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <!--end::Script-->
  </body>
  <!--end::Body-->
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webChecker/resources/views/user/layouts/components/app-layout.blade.php ENDPATH**/ ?>