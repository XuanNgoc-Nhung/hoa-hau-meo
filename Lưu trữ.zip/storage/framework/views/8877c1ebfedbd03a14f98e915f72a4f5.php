<?php $__env->startSection('content'); ?>
<!--begin::App Content Header-->
<div class="app-content-header">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row">
            <div class="col-sm-12">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.dashboard')); ?>">Trang chủ</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($danhMuc->ten_danh_muc); ?></li>
                </ol>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content Header-->

<!--begin::App Content-->
<div class="app-content">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Danh sách diễn đàn - <?php echo e($danhMuc->ten_danh_muc); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php if($dienDan->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <tbody>
                                        <?php $__currentLoopData = $dienDan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-start">
                                                        <!-- Hình ảnh -->
                                                        <div class="me-3 flex-shrink-0">
                                                            <?php if($dien->hinh_anh): ?>
                                                                <?php
                                                                    // Xử lý hinh_anh - lấy URL đầu tiên từ danh sách
                                                                    $hinhAnhArray = explode("\n", $dien->hinh_anh);
                                                                    $hinhAnhArray = array_filter($hinhAnhArray, function($url) {
                                                                        return !empty(trim($url));
                                                                    });
                                                                    $imagePath = !empty($hinhAnhArray) ? trim($hinhAnhArray[0]) : null;
                                                                ?>
                                                                <?php if($imagePath): ?>
                                                                <a href="<?php echo e(route('dien-dan.chi-tiet', [ 'slug' => $dien->slug])); ?>">
                                                                    <img src="<?php echo e($imagePath); ?>"
                                                                         class="img-fluid rounded"
                                                                         alt="<?php echo e($dien->ten_dien_dan); ?>"
                                                                         style="width: 60px; height: 60px; object-fit: cover;">
                                                                </a>
                                                                <?php else: ?>
                                                                    <div class="d-flex align-items-center justify-content-center bg-light rounded"
                                                                         style="width: 60px; height: 60px;">
                                                                        <i class="fas fa-image text-muted" style="font-size: 1.2rem;"></i>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="d-flex align-items-center justify-content-center bg-light rounded"
                                                                     style="width: 60px; height: 60px;">
                                                                    <i class="fas fa-image text-muted" style="font-size: 1.2rem;"></i>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        
                                                        <!-- Thông tin diễn đàn -->
                                                        <div class="flex-grow-1">
                                                            <!-- Tên diễn đàn có thể click -->
                                                            <h5 class="mb-2 fw-bold">
                                                                <a href="<?php echo e(route('dien-dan.chi-tiet', [ 'slug' => $dien->slug])); ?>" 
                                                                   class="text-primary text-decoration-none">
                                                                    <?php echo e($dien->ten_dien_dan); ?>

                                                                </a>
                                                                <small class="text-success ms-2 fst-italic" style="font-size: 0.75rem;">
                                                                    <i class="fas fa-comments me-2 text-success"></i>
                                                                    <?php echo e($dien->last_comment); ?>

                                                                </small>
                                                            </h5>
                                                            
                                                            <!-- Vị trí, giá, trạng thái -->
                                                            <div>
                                                                <?php if($dien->vi_tri): ?>
                                                                    <span class="badge bg-info me-2"><i class="fas fa-map-marker-alt"></i> <?php echo e($dien->vi_tri); ?></span>
                                                                <?php endif; ?>
                                                                <?php if($dien->muc_gia): ?>
                                                                    <span class="badge bg-warning text-dark me-2"><i class="fas fa-coins"></i> <?php echo e($dien->muc_gia); ?></span>
                                                                <?php endif; ?>
                                                                <?php if($dien->trang_thai): ?>
                                                                    <span class="badge bg-success">Hoạt động</span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-secondary">Không hoạt động</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-column text-muted small">
                                                        <div class="mb-1">
                                                            <i class="fas fa-eye me-2 text-info"></i>
                                                            <span><?php echo e($dien->total_view ?? rand(10, 500)); ?></span>
                                                        </div>
                                                        <div>
                                                            <i class="fas fa-comments me-2 text-success"></i>
                                                            <span><?php echo e($dien->total_comment ?? rand(0, 50)); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-column text-muted small">
                                                        <div class="mb-1">
                                                            <i class="fas fa-user me-2 text-primary"></i>
                                                            <span><?php echo e($dien->user->name ?? 'Admin'); ?></span>
                                                        </div>
                                                        <div class="mb-1">
                                                            <i class="fas fa-clock me-2 text-warning"></i>
                                                            <span><?php echo e($dien->created_at->diffForHumans()); ?></span>
                                                        </div>
                                                        
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination -->
                            <?php if($dienDan->hasPages()): ?>
                                <div class="d-flex justify-content-center mt-4">
                                    <?php echo e($dienDan->links()); ?>

                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox text-muted" style="font-size: 4rem;"></i>
                                <h5 class="mt-3 text-muted">Chưa có diễn đàn nào trong danh mục này</h5>
                                <p class="text-muted">Hãy quay lại sau hoặc chọn danh mục khác</p>
                                <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-primary">
                                    <i class="fas fa-arrow-left me-2"></i>Quay về trang chủ
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            

            <div class="col-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Khu vực nhộn nhịp - Diễn bình luận mới nhất</h4>
                    </div>
                    <div class="card-body">
                        <?php if($dienDanBinhLuanMoi->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <tbody>
                                        <?php $__currentLoopData = $dienDanBinhLuanMoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-start">
                                                        <!-- Hình ảnh -->
                                                        <div class="me-3 flex-shrink-0">
                                                            <?php if($dien->hinh_anh): ?>
                                                                <?php
                                                                    // Xử lý hinh_anh - lấy URL đầu tiên từ danh sách
                                                                    $hinhAnhArray = explode("\n", $dien->hinh_anh);
                                                                    $hinhAnhArray = array_filter($hinhAnhArray, function($url) {
                                                                        return !empty(trim($url));
                                                                    });
                                                                    $imagePath = !empty($hinhAnhArray) ? trim($hinhAnhArray[0]) : null;
                                                                ?>
                                                                <?php if($imagePath): ?>
                                                                <a href="<?php echo e(route('dien-dan.chi-tiet', [ 'slug' => $dien->slug])); ?>">
                                                                    <img src="<?php echo e($imagePath); ?>"
                                                                         class="img-fluid rounded"
                                                                         alt="<?php echo e($dien->ten_dien_dan); ?>"
                                                                         style="width: 60px; height: 60px; object-fit: cover;">
                                                                </a>
                                                                <?php else: ?>
                                                                    <div class="d-flex align-items-center justify-content-center bg-light rounded"
                                                                         style="width: 60px; height: 60px;">
                                                                        <i class="fas fa-image text-muted" style="font-size: 1.2rem;"></i>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="d-flex align-items-center justify-content-center bg-light rounded"
                                                                     style="width: 60px; height: 60px;">
                                                                    <i class="fas fa-image text-muted" style="font-size: 1.2rem;"></i>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        
                                                        <!-- Thông tin diễn đàn -->
                                                        <div class="flex-grow-1">
                                                            <!-- Tên diễn đàn có thể click -->
                                                            <h5 class="mb-2 fw-bold">
                                                                <a href="<?php echo e(route('dien-dan.chi-tiet', [ 'slug' => $dien->slug])); ?>" 
                                                                   class="text-primary text-decoration-none">
                                                                    <?php echo e($dien->ten_dien_dan); ?>

                                                                </a>
                                                                <small class="text-success ms-2 fst-italic" style="font-size: 0.75rem;">
                                                                    <i class="fas fa-comments me-2 text-success"></i>
                                                                    <?php echo e($dien->last_comment); ?>

                                                                </small>
                                                            </h5>
                                                            
                                                            <!-- Vị trí, giá, trạng thái -->
                                                            <div>
                                                                <?php if($dien->vi_tri): ?>
                                                                    <span class="badge bg-info me-2"><i class="fas fa-map-marker-alt"></i> <?php echo e($dien->vi_tri); ?></span>
                                                                <?php endif; ?>
                                                                <?php if($dien->muc_gia): ?>
                                                                    <span class="badge bg-warning text-dark me-2"><i class="fas fa-coins"></i> <?php echo e($dien->muc_gia); ?></span>
                                                                <?php endif; ?>
                                                                <?php if($dien->trang_thai): ?>
                                                                    <span class="badge bg-success">Hoạt động</span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-secondary">Không hoạt động</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-column text-muted small">
                                                        <div class="mb-1">
                                                            <i class="fas fa-eye me-2 text-info"></i>
                                                            <span><?php echo e($dien->total_view ?? rand(10, 500)); ?></span>
                                                        </div>
                                                        <div>
                                                            <i class="fas fa-comments me-2 text-success"></i>
                                                            <span><?php echo e($dien->total_comment ?? rand(0, 50)); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-column text-muted small">
                                                        <div class="mb-1">
                                                            <i class="fas fa-user me-2 text-primary"></i>
                                                            <span><?php echo e($dien->user->name ?? 'Admin'); ?></span>
                                                        </div>
                                                        <div class="mb-1">
                                                            <i class="fas fa-clock me-2 text-warning"></i>
                                                            <span><?php echo e($dien->created_at->diffForHumans()); ?></span>
                                                        </div>
                                                        
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox text-muted" style="font-size: 4rem;"></i>
                                <h5 class="mt-3 text-muted">Chưa có diễn đàn nào trong danh mục này</h5>
                                <p class="text-muted">Hãy quay lại sau hoặc chọn danh mục khác</p>
                                <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-primary">
                                    <i class="fas fa-arrow-left me-2"></i>Quay về trang chủ
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            

            <div class="col-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Có thể bạn quan tâm - Diễn đàn mới nhất</h4>
                    </div>
                    <div class="card-body">
                        <?php if($dienDanMoi->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <tbody>
                                        <?php $__currentLoopData = $dienDanMoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-start">
                                                        <!-- Hình ảnh -->
                                                        <div class="me-3 flex-shrink-0">
                                                            <?php if($dien->hinh_anh): ?>
                                                                <?php
                                                                    // Xử lý hinh_anh - lấy URL đầu tiên từ danh sách
                                                                    $hinhAnhArray = explode("\n", $dien->hinh_anh);
                                                                    $hinhAnhArray = array_filter($hinhAnhArray, function($url) {
                                                                        return !empty(trim($url));
                                                                    });
                                                                    $imagePath = !empty($hinhAnhArray) ? trim($hinhAnhArray[0]) : null;
                                                                ?>
                                                                <?php if($imagePath): ?>
                                                                <a href="<?php echo e(route('dien-dan.chi-tiet', [ 'slug' => $dien->slug])); ?>">
                                                                    <img src="<?php echo e($imagePath); ?>"
                                                                         class="img-fluid rounded"
                                                                         alt="<?php echo e($dien->ten_dien_dan); ?>"
                                                                         style="width: 60px; height: 60px; object-fit: cover;">
                                                                </a>
                                                                <?php else: ?>
                                                                    <div class="d-flex align-items-center justify-content-center bg-light rounded"
                                                                         style="width: 60px; height: 60px;">
                                                                        <i class="fas fa-image text-muted" style="font-size: 1.2rem;"></i>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="d-flex align-items-center justify-content-center bg-light rounded"
                                                                     style="width: 60px; height: 60px;">
                                                                    <i class="fas fa-image text-muted" style="font-size: 1.2rem;"></i>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        
                                                        <!-- Thông tin diễn đàn -->
                                                        <div class="flex-grow-1">
                                                            <!-- Tên diễn đàn có thể click -->
                                                            <h5 class="mb-2 fw-bold">
                                                                <a href="<?php echo e(route('dien-dan.chi-tiet', [ 'slug' => $dien->slug])); ?>" 
                                                                   class="text-primary text-decoration-none">
                                                                    <?php echo e($dien->ten_dien_dan); ?>

                                                                </a>
                                                                <small class="text-success ms-2 fst-italic" style="font-size: 0.75rem;">
                                                                    <i class="fas fa-comments me-2 text-success"></i>
                                                                    <?php echo e($dien->last_comment); ?>

                                                                </small>
                                                            </h5>
                                                            
                                                            <!-- Vị trí, giá, trạng thái -->
                                                            <div>
                                                                <?php if($dien->vi_tri): ?>
                                                                    <span class="badge bg-info me-2"><i class="fas fa-map-marker-alt"></i> <?php echo e($dien->vi_tri); ?></span>
                                                                <?php endif; ?>
                                                                <?php if($dien->muc_gia): ?>
                                                                    <span class="badge bg-warning text-dark me-2"><i class="fas fa-coins"></i> <?php echo e($dien->muc_gia); ?></span>
                                                                <?php endif; ?>
                                                                <?php if($dien->trang_thai): ?>
                                                                    <span class="badge bg-success">Hoạt động</span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-secondary">Không hoạt động</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-column text-muted small">
                                                        <div class="mb-1">
                                                            <i class="fas fa-eye me-2 text-info"></i>
                                                            <span><?php echo e($dien->total_view ?? rand(10, 500)); ?></span>
                                                        </div>
                                                        <div>
                                                            <i class="fas fa-comments me-2 text-success"></i>
                                                            <span><?php echo e($dien->total_comment ?? rand(0, 50)); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex flex-column text-muted small">
                                                        <div class="mb-1">
                                                            <i class="fas fa-user me-2 text-primary"></i>
                                                            <span><?php echo e($dien->user->name ?? 'Admin'); ?></span>
                                                        </div>
                                                        <div class="mb-1">
                                                            <i class="fas fa-clock me-2 text-warning"></i>
                                                            <span><?php echo e($dien->created_at->diffForHumans()); ?></span>
                                                        </div>
                                                        
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox text-muted" style="font-size: 4rem;"></i>
                                <h5 class="mt-3 text-muted">Chưa có diễn đàn nào trong danh mục này</h5>
                                <p class="text-muted">Hãy quay lại sau hoặc chọn danh mục khác</p>
                                <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-primary">
                                    <i class="fas fa-arrow-left me-2"></i>Quay về trang chủ
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <!--end::Container-->
</div>
<!--end::App Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function viewDetail(id) {
    // Có thể thêm modal hoặc chuyển hướng đến trang chi tiết
    alert('Xem chi tiết diễn đàn ID: ' + id);
    // window.location.href = '/dien-dan-detail/' + id;
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.components.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webChecker/resources/views/user/dien-dan/dien-dan-theo-danh-muc.blade.php ENDPATH**/ ?>