<footer class="app-footer">
  <!--begin::To the end-->
  <div class="float-end d-none d-sm-inline">Nhận xét Mèo - 2025</div>
  <!--end::To the end-->
  <!--begin::Copyright-->
  <strong>
    Đã đăng ký bản quyền 
    <a href="<?php echo e(route('user.dashboard')); ?>" class="text-decoration-none">checker-meo.com</a>.
  </strong>
  <!--end::Copyright-->
</footer> 

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script
      src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.10.1/browser/overlayscrollbars.browser.es6.min.js"
      integrity="sha256-dghWARbRe2eLlIJ56wNB+b760ywulqK3DzZYEpsg2fQ="
      crossorigin="anonymous"
    ></script>
    <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
      integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
      crossorigin="anonymous"
    ></script>
    <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
    <script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
    <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
    <script>
      const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
      const Default = {
        scrollbarTheme: 'os-theme-light',
        scrollbarAutoHide: 'leave',
        scrollbarClickScroll: true,
      };
      document.addEventListener('DOMContentLoaded', function () {
        const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
        if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
          OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
            scrollbars: {
              theme: Default.scrollbarTheme,
              autoHide: Default.scrollbarAutoHide,
              clickScroll: Default.scrollbarClickScroll,
            },
          });
        }
      });
    </script>
    <!--end::OverlayScrollbars Configure-->
    <!-- OPTIONAL SCRIPTS -->
    <!-- apexcharts -->
    <script
      src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"
      integrity="sha256-+vh8GkaU7C9/wbSLIcwq82tQ2wTf44aOHA8HlBMwRI8="
      crossorigin="anonymous"
    ></script>
    <!-- jsvectormap -->
    <script
      src="https://cdn.jsdelivr.net/npm/jsvectormap@1.5.3/dist/js/jsvectormap.min.js"
      integrity="sha256-/t1nN2956BT869E6H4V1dnt0X5pAQHPytli+1nTZm2Y="
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/jsvectormap@1.5.3/dist/maps/world.js"
      integrity="sha256-XPpPaZlU8S/HWf7FZLAncLg2SAkP8ScUTII89x9D3lY="
      crossorigin="anonymous"
    ></script>
    <!-- jsvectormap -->
    <script>
      // World map by jsVectorMap
      const worldMapElement = document.querySelector('#world-map');
      if (worldMapElement) {
        new jsVectorMap({
          selector: '#world-map',
          map: 'world',
        });
      }

      // Sparkline charts
      const option_sparkline1 = {
        series: [
          {
            data: [1000, 1200, 920, 927, 931, 1027, 819, 930, 1021],
          },
        ],
        chart: {
          type: 'area',
          height: 50,
          sparkline: {
            enabled: true,
          },
        },
        stroke: {
          curve: 'straight',
        },
        fill: {
          opacity: 0.3,
        },
        yaxis: {
          min: 0,
        },
        colors: ['#DCE6EC'],
      };

      const sparkline1Element = document.querySelector('#sparkline-1');
      if (sparkline1Element) {
        const sparkline1 = new ApexCharts(sparkline1Element, option_sparkline1);
        sparkline1.render();
      }

      const option_sparkline2 = {
        series: [
          {
            data: [515, 519, 520, 522, 652, 810, 370, 627, 319, 630, 921],
          },
        ],
        chart: {
          type: 'area',
          height: 50,
          sparkline: {
            enabled: true,
          },
        },
        stroke: {
          curve: 'straight',
        },
        fill: {
          opacity: 0.3,
        },
        yaxis: {
          min: 0,
        },
        colors: ['#DCE6EC'],
      };

      const sparkline2Element = document.querySelector('#sparkline-2');
      if (sparkline2Element) {
        const sparkline2 = new ApexCharts(sparkline2Element, option_sparkline2);
        sparkline2.render();
      }

      const option_sparkline3 = {
        series: [
          {
            data: [15, 19, 20, 22, 33, 27, 31, 27, 19, 30, 21],
          },
        ],
        chart: {
          type: 'area',
          height: 50,
          sparkline: {
            enabled: true,
          },
        },
        stroke: {
          curve: 'straight',
        },
        fill: {
          opacity: 0.3,
        },
        yaxis: {
          min: 0,
        },
        colors: ['#DCE6EC'],
      };

      const sparkline3Element = document.querySelector('#sparkline-3');
      if (sparkline3Element) {
        const sparkline3 = new ApexCharts(sparkline3Element, option_sparkline3);
        sparkline3.render();
      }
    </script>
    
    <!-- AdminLTE Initialization -->
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        // Initialize AdminLTE
        if (typeof AdminLTE !== 'undefined') {
          AdminLTE.init();
        }
        
        // Initialize card widgets manually if needed
        if (typeof CardWidget !== 'undefined') {
          const cards = document.querySelectorAll('.card');
          cards.forEach(card => {
            new CardWidget(card);
          });
        }
        
        // Check if AdminLTE card functionality is available
        if (typeof AdminLTE !== 'undefined' && AdminLTE.CardWidget) {
          console.log('AdminLTE CardWidget is available');
          // Initialize all cards with AdminLTE CardWidget
          const cards = document.querySelectorAll('.card');
          cards.forEach(card => {
            new AdminLTE.CardWidget(card);
          });
        } else {
          console.log('AdminLTE CardWidget is not available, using manual implementation');
        }
      });
    </script><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webChecker/resources/views/user/layouts/components/footer.blade.php ENDPATH**/ ?>